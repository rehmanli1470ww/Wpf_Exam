﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfImtahan.Models;

namespace WpfImtahan.Statics
{
    public static class GetUser
    {

        public static List<User> Users { get; set; }
        public static List<Car> car { get; set; }
    }
}
