﻿using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using WpfImtahan.Commands;
using WpfImtahan.Views.Pages;

namespace WpfImtahan.ViewsModels
{
    public class MyWindowsBackEnd 
    {
      
    }

    
}
